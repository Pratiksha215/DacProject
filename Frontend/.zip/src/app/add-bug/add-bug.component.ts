import { IssuesService } from './../issues.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-bug',
  templateUrl: './add-bug.component.html',
  styleUrls: ['./add-bug.component.css']
})
export class AddBugComponent implements OnInit {
  name=''
  summary=''
  createdBy=''
  priority=''
  severity=''
  status=''
  startDate=''
  targetEndDate=''
  actualEndDate=''
  projectId=''
  assignedTo=''
  modifiedBy=''
  modifiedOn=''


  constructor(private router:Router,
    private IssuesService:IssuesService) { }

  ngOnInit(): void {
  }

  onCancel(){
    this.router.navigate(['/issues'])
  }
  onUpdate(){
    this.router.navigate(['/issues'])
    
  }

}
