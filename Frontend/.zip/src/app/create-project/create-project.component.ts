import { ProjectsService } from './../projects.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ObjectUnsubscribedError } from 'rxjs';

@Component({
  selector: 'app-create-project',
  templateUrl: './create-project.component.html',
  styleUrls: ['./create-project.component.css']
})
export class CreateProjectComponent implements OnInit {

  id=0
  name=''
  createdBy=''
  startDate=''
  targetEndDate=''
  actualEndDate=''
  modifiedBy=''
  modifiedOn=''
  project=[]

  constructor(private router:Router,
    private activatedRoute: ActivatedRoute,
    private projectsService:ProjectsService) { }


  ngOnInit(): void {
    const id = this.activatedRoute.snapshot.queryParams['id']
    if (id){
      //edit
      this.projectsService
      .getProjectsDetails(id)
      .subscribe((response: { [x: string]: any; }) => {
        console.log(response)
        if (response['status'] == 'success'){
          const projects = response['data']
          console.log(projects)
          //if (projects.length > 0){
            if(Object.keys(projects).length>0){
            this.project =projects           
            this.name =projects['name']
            this.createdBy =projects['createdBy']
            this.startDate =projects['startDate']
            this.targetEndDate =projects['targetEndDate']
          }
        }
      })
    }
  }

  



  onCancel(){
    this.router.navigate(['/projects'])
  }
  onUpdate() {

    if (this.project) {
      // edit

      
      this.projectsService
        .updateProject(this.id, this.name, this.startDate, this.targetEndDate, this.actualEndDate)//this.project['id']
        .subscribe((response: { [x: string]: any; }) => {
          if (response['status'] == 'success') {
            this.router.navigate(['/project'])
          }
        })
    } else {
      // insert
      this.projectsService
        .insertProject(this.name, this.startDate, this.targetEndDate, this.actualEndDate)
        .subscribe((response: { [x: string]: any; }) => {
          if (response['status'] == 'success') {
            this.router.navigate(['/project'])
          }
        })
    }
}


}