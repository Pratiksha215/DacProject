import { AddBugComponent } from './../add-bug/add-bug.component';
import { IssuesService } from './../issues.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-issues',
  templateUrl: './issues.component.html',
  styleUrls: ['./issues.component.css']
})
export class IssuesComponent implements OnInit {

  issues=[]

  constructor(private router:Router, 
    private issuessService:IssuesService) { }


  ngOnInit(): void {
  }

  onEdit(bug: { [x: string]: any; }){
    this.router.navigate(['/add-bug'],{queryParams:{id:bug['id']}})
  }
  
  onAddBug(){
    this.router.navigate(['/add-bug'])

  }

}
