import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProjectsService 
{
  url=''
  //getProjectsDetails: any;

  constructor(private httpClient:HttpClient) { }
  getProjects(){

    //add person name /token in request header
    const httpOptions={
      headers:new HttpHeaders({
        personName:sessionStorage['personName']
      })
    };
    return this.httpClient.get(this.url,httpOptions)

  }
  getProjectsDetails(id: string) {
    return this.httpClient.get(this.url+ "/" +id)
  }

  // getProjectsDetails(id: string) {
  //   // add the token in the request header
  //   const httpOptions = {
  //    headers: new HttpHeaders({
  //      personName: sessionStorage['personName']
  //    })
  //  };
   
   //return this.httpClient.get(this.url + "/details/" + id, httpOptions)

 
   updateProject(id:number, name: string, createdBy: string, startDate: string, targetEndDate: string) {
    const body={
      id:id,
      name:name,
      createdBy:createdBy,
      startDate:startDate,
      targetEndDate:targetEndDate
  }
  console.log(body)
  return this.httpClient.put(this.url+"/"+id,body)
}

insertProject(name:string,createdOn:string,startDate:string,targetEndDate:string){
  const body={
    name:name,
    createdOn:createdOn,
    startDate:startDate,
    targetEndDate:targetEndDate

  }

  return this.httpClient.post(this.url,body)
}

// deleteMenu()
// {
//   return this.httpClient.delete(this.url+"/"+'id')
// }

}

  