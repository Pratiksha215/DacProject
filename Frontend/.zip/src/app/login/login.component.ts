import { LoginService } from './../login.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email=''
  password=''

  constructor(
    private router: Router,
    private loginService : LoginService) { }

  ngOnInit(): void {
    
  }


  // onLogin(){
  //   this.loginService
  //   .login(this.email, this.password)
  //   .subscribe(response => {
  //     if (response['status'] == 'success'){
  //       console.log(response)
  //         const data = response['data']
  //         if(data['role']=='Manager'){
  //           sessionStorage['emp_first_name'] = data['emp_first_name']
  //           sessionStorage['emp_last_name'] = data['emp_last_name'] 
  
  //           this.router.navigate(['/dashboard']) 
  //         }else{
  //           alert('You are not a manager')
  //         } 
  //     }else{
  //       alert('invalid username or password')
  //     }
  //   })  
  // }




  onLogin() {
    this.loginService
      .login(this.email, this.password)
      .subscribe((response: { [x: string]: any; }) => {
        
        if (response['status'] == 'success') {
          const data = response['data']
          //console.log(data)

          // cache the user info
          //sessionStorage['token'] = data['token']
          sessionStorage['personName'] = data['personName']
          //sessionStorage['lastName'] = data['lastName']
          this.router.navigate(['/dashboard'])
        } else {
          alert('invalid email or password')
        }     
      })
      //hardcoded
      sessionStorage['personName'] = 'Himani'
      this.router.navigate(['/dashboard'])
    }

    onSignup(){
      this.router.navigate(['/signup'])
    }

  }
 

  


