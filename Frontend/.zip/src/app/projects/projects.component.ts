import { ProjectsService } from './../projects.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})
export class ProjectsComponent implements OnInit {
  projects=[]
  
  constructor(private router:Router, 
    private activatedRoute: ActivatedRoute,
    private projectsService:ProjectsService) { }

  ngOnInit(): void {
  }


  loadProjects()
  {
    this.projectsService
    .getProjects()
    .subscribe((response: { [x: string]: any; })=>
    {
      if(response['status']=='success')
      {
        this.projects=response['data']
      }
      else
      {
        console.log(response['error'])
      }
    })

  }

  onEdit(project: { [x: string]: any; }){
    this.router.navigate(['/create-project'],{queryParams:{id:project['id']}})
  }

  onCreateProject(){
    this.router.navigate(['/create-project'])
  }

}
 

