import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService implements CanActivate{

  //url of login api
  url=''
  

  constructor(private router:Router,
    private httpClient:HttpClient) { }


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    if(sessionStorage['personName']){
    //user is already logged in
    //launch the component
    return true
    }
    else{
    
      //force user to login
     this.router.navigate(['/login'])
    //user has not logged in yet
    //to stop launching the component
    return false
   }
  }

  login(email:string,password:string){
    const body={
      email:email,
      password:password
    }
    return this.httpClient.post(this.url+'/signup',body)

  }
}
